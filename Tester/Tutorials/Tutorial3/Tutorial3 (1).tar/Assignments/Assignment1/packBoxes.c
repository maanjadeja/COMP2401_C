#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
  int randomValues[3];


  srand(time(NULL));
  printf("The Random Numbers Are:\n");

  int min=1, max = 24;
  int x = (rand()% (min - max + 1)) + min;
  int min2=1, max2 = 24-x;
  int y = (rand()% (min2 - max2 + 1)) + min2;
  int z=0;
  if(x+y<24){
    z = 24 - (x+y);
  }
  //int z = (rand()% (min3 - max3 + 1)) + min3;

  printf("%d %d %d\n",x,y,z);
  printf("Large Packages: %d\n",x);
  printf("Medium Packages: %d\n",y);
  printf("Small Packages: %d\n",z);

  //Area Calculation
  int largePackageArea = x * 4;
  int mediumPackageArea = y * 2;
  int smallPackageArea = z;

  printf("\n");
  printf("TOTAL AREA CALCULATED:\n");
  printf("Large Package: %d\n", largePackageArea );
  printf("Medium Package: %d\n", mediumPackageArea );
  printf("Small Package: %d\n", smallPackageArea );


  /*for (int i=0; i<3; i++){
    int num = (rand()% (min - max + 1)) + min;
    printf("%d\n", num);
    randomValues[i]=num;
  }
  printf("The List holds:\n");
  for (int j=0; j<3; j++){
    printf("%d\n", randomValues[j] );
  }*/
}
