#include<stdio.h>
#include<stdlib.h>

void printTriangleRecursive(int numRows){

  if(numRows==0){
    return;
  }
  else{

    for (int i=numRows; i>0; i--){
      printf("*");
    }
    printf("\n" );
    printTriangleRecursive(numRows-1);
  }

}

void main(){
  printTriangleRecursive(9);
}
