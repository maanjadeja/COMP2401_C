#include<stdio.h>
#include<stdlib.h>

void printTriangleRecursive(int numRows){

  if(numRows==0){
    return;
  }
  else{
    printTriangleRecursive(numRows-1);
    for (int i=0; i<numRows; i++){
      printf("*");
    }
    printf("\n" );
  }

}

void main(){
  printTriangleRecursive(5);
}
